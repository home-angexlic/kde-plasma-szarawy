# kde-plasma-szarawy


wszystko do pobrania tak wsm jak w bialym tlyko theme jest inny tbh
